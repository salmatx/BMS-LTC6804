var structconfiguration__t =
[
    [ "battery", "structconfiguration__t.html#a50d4b6ad377eea8df311b053633a7d57", null ],
    [ "mqtt", "structconfiguration__t.html#ab1fb6be622b20687374d9acc55174726", null ],
    [ "wifi", "structconfiguration__t.html#ae5d55bd42b637ee0ce17d5633252175c", null ]
];