var bms__configuration_8h =
[
    [ "bms_config_t", "structbms__config__t.html", "structbms__config__t" ],
    [ "bms_adapter_mode_t", "bms__configuration_8h.html#a294d13fcab0a25ae1cd684b1ee2a0c43", [
      [ "BMS_ADAPTER_LTC6804", "bms__configuration_8h.html#a294d13fcab0a25ae1cd684b1ee2a0c43a75ef7b61aa87e5f9da58bdc9788bc2b2", null ],
      [ "BMS_ADAPTER_DEMO", "bms__configuration_8h.html#a294d13fcab0a25ae1cd684b1ee2a0c43acaaca1c0eb156f8bafc6254c1e39734f", null ]
    ] ]
];