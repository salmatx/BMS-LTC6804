var tasksSC_8h =
[
    [ "slow_core_task_create", "tasksSC_8h.html#ae38af1d6cb4b17fcf74d0d26d2c3a7f9", null ],
    [ "slow_core_TWDT_create", "tasksSC_8h.html#abedb04a3c128208de3ce983e6d80f12b", null ],
    [ "slow_core_TWDT_delete", "tasksSC_8h.html#af5b261d5ab9163f49ab38434a3d38456", null ]
];