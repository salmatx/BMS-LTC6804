var dir_1dc745a558826d0d5751d86c3529451b =
[
    [ "configuration", "dir_275b695224c79684a93e4d9245a12f10.html", "dir_275b695224c79684a93e4d9245a12f10" ],
    [ "network", "dir_b03080277bb50c7c943c1aef7da72430.html", "dir_b03080277bb50c7c943c1aef7da72430" ],
    [ "json_formatter.c", "json__formatter_8c.html", "json__formatter_8c" ],
    [ "json_formatter.h", "json__formatter_8h.html", "json__formatter_8h" ],
    [ "process.c", "process_8c.html", "process_8c" ],
    [ "process.h", "process_8h.html", "process_8h" ]
];