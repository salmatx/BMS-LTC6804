var bms__data_8h =
[
    [ "bms_sample_t", "structbms__sample__t.html", "structbms__sample__t" ],
    [ "bms_sample_buffer_t", "structbms__sample__buffer__t.html", "structbms__sample__buffer__t" ],
    [ "BMS_MAX_CELLS", "bms__data_8h.html#a4506acdc1e28799838327534e987cf80", null ],
    [ "bms_buf_index", "bms__data_8h.html#a80e6b3cb51600e4a8e64d0e0daf45735", null ]
];