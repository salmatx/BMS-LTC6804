var structrtc__log__buf__t =
[
    [ "count", "structrtc__log__buf__t.html#aad5727b5b6252b913373bc2bd9336d73", null ],
    [ "entries", "structrtc__log__buf__t.html#a16699842e48594fff6ec92e76d4f880e", null ],
    [ "head", "structrtc__log__buf__t.html#a5102db9d72674f836fea450485618a02", null ],
    [ "magic", "structrtc__log__buf__t.html#a82be6d7bf594bbf02e6103ba58f19ee5", null ]
];