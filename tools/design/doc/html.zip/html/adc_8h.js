var adc_8h =
[
    [ "ADC_RANGE", "adc_8h.html#af6510ec9c01be68b14a02327ef5889e1", null ],
    [ "adc_pin_t", "adc_8h.html#aa67449fc04973235c7113ef2e926af15", [
      [ "ADC_PIN_GPIO34", "adc_8h.html#aa67449fc04973235c7113ef2e926af15a6f0517a57308f56dd384b4ee844cf11f", null ],
      [ "ADC_PIN_GPIO35", "adc_8h.html#aa67449fc04973235c7113ef2e926af15a7282bf14295f3db156dea87433db29dd", null ],
      [ "ADC_PIN_GPIO36", "adc_8h.html#aa67449fc04973235c7113ef2e926af15a512f2bb95d785d3014cfecc713549d54", null ],
      [ "ADC_PIN_GPIO39", "adc_8h.html#aa67449fc04973235c7113ef2e926af15a1f3b89ba473648d78aceb0d4893fb7c7", null ]
    ] ],
    [ "adc_init", "adc_8h.html#a3cfa671db431099a0d91bd8bcfe935f8", null ],
    [ "adc_read", "adc_8h.html#a7eb91885a956bff9a16e36678790aa9b", null ]
];