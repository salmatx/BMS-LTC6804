var main_8c =
[
    [ "LOG_MODULE_TAG", "main_8c.html#a30f768357b7db6b4ef775e43f9580496", null ],
    [ "app_main", "main_8c.html#a630544a7f0a2cc40d8a7fefab7e2fe70", null ]
];