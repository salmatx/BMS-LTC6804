var structbms__sample__buffer__t =
[
    [ "capacity", "structbms__sample__buffer__t.html#a38e3e90f30c525edeb0373db12aea5d8", null ],
    [ "count", "structbms__sample__buffer__t.html#af663e85534cd15ebc7eab27b360918fd", null ],
    [ "head", "structbms__sample__buffer__t.html#aac981cd1a096b31c4e7d5ac227481e5d", null ],
    [ "samples", "structbms__sample__buffer__t.html#a75a75b90c51c33b2768997ecde5497db", null ]
];