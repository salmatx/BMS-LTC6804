var structbms__adapter__t =
[
    [ "init", "structbms__adapter__t.html#afb4b726e39ffaac47ecc06921231761e", null ],
    [ "read_sample", "structbms__adapter__t.html#a87994a5fb26aa30ed0ffd34e979b2ff6", null ]
];