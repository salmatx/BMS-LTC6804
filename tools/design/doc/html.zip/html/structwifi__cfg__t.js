var structwifi__cfg__t =
[
    [ "gateway", "structwifi__cfg__t.html#ae27af0fab28c5172677802bc7d860632", null ],
    [ "netmask", "structwifi__cfg__t.html#a1a637447842a53c5407e50426f75291a", null ],
    [ "pass", "structwifi__cfg__t.html#a045ee7acfe821584e4ca01cd6e8798e9", null ],
    [ "ssid", "structwifi__cfg__t.html#a97230173ea2ffd5c676d95e4a5f9419d", null ],
    [ "static_ip", "structwifi__cfg__t.html#af9b20c27fd824c76f4bd5f73c6b4cc0e", null ]
];