var tasksSC_8c =
[
    [ "CORE0_SW_STROBE_MS", "tasksSC_8c.html#ae44bc254e3397c9cf96719c5357edcf0", null ],
    [ "CORE0_SW_TIMEOUT_MS", "tasksSC_8c.html#a6ba35ad3cd416b0c0e01a28d5f49a991", null ],
    [ "LOG_MODULE_TAG", "tasksSC_8c.html#a30f768357b7db6b4ef775e43f9580496", null ],
    [ "WDT_FEED_MS", "tasksSC_8c.html#aa4cdd0806e863a45a6f624a6c6a620ff", null ],
    [ "slow_core_feeder_task", "tasksSC_8c.html#a5e5f16bfb29887689f8b3a3dc269c0ac", null ],
    [ "slow_core_task", "tasksSC_8c.html#a6cdc52f6204c831e12913afcebe8db77", null ],
    [ "slow_core_task_create", "tasksSC_8c.html#ae38af1d6cb4b17fcf74d0d26d2c3a7f9", null ],
    [ "slow_core_TWDT_create", "tasksSC_8c.html#abedb04a3c128208de3ce983e6d80f12b", null ],
    [ "slow_core_TWDT_delete", "tasksSC_8c.html#af5b261d5ab9163f49ab38434a3d38456", null ],
    [ "s_allow_feeding", "tasksSC_8c.html#a047c38161daa09f5f0f069416ab1d3b4", null ],
    [ "s_should_exit_feeder", "tasksSC_8c.html#ab00dd5bb3562c8b3c577dd3595a019fe", null ],
    [ "s_slow_core_feeder_handle", "tasksSC_8c.html#adfb7296a1c8fe9d747c21bf65b1d067a", null ]
];