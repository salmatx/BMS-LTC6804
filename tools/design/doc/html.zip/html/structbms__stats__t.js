var structbms__stats__t =
[
    [ "cell_errors", "structbms__stats__t.html#aa7b42b6e0ede71b584e184ab2f808708", null ],
    [ "cell_v_avg", "structbms__stats__t.html#a9a3eacc523837e0a9739afd9ea41aaec", null ],
    [ "pack_i_avg", "structbms__stats__t.html#adb33b144642824c83c03ca73eb3b80ed", null ],
    [ "pack_v_avg", "structbms__stats__t.html#acce0387cd578a8cfb2b795d693260ded", null ],
    [ "sample_count", "structbms__stats__t.html#a68b547ca70c4ed07e1c42b8fede5e859", null ],
    [ "temperature_avg", "structbms__stats__t.html#afb0c951811984de33a7bebd363b5839a", null ],
    [ "timestamp", "structbms__stats__t.html#ad98deb7c519f235bb5b81d01e8d708f8", null ]
];