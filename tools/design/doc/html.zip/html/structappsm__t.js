var structappsm__t =
[
    [ "curr_state", "structappsm__t.html#a3497befab95bef353d51c362364a6bf6", null ],
    [ "next_state", "structappsm__t.html#a1e66892888d421a12a1bc664282e7917", null ],
    [ "prev_state", "structappsm__t.html#a0a5e9df62b041a48633e8c1de61ccac2", null ]
];