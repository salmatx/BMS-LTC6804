var structesp32__telemetry__t =
[
    [ "cpu_load", "structesp32__telemetry__t.html#a730e0530665ba9654428bac7f1dae113", null ],
    [ "device_id", "structesp32__telemetry__t.html#aaaff2ebeba9009c7e0a287e3c3dd8c14", null ],
    [ "free_heap", "structesp32__telemetry__t.html#a4158cdf4e8e90c8dba53aebaa6f9fb65", null ],
    [ "min_free_heap", "structesp32__telemetry__t.html#ac582b1bde9274eab3e6cdfc11f403620", null ],
    [ "reset_msg", "structesp32__telemetry__t.html#a662f245ab24c9db055919ddd0e83c6c0", null ],
    [ "reset_reason", "structesp32__telemetry__t.html#a02b018ac50ffe3703d82e374d2279ed2", null ],
    [ "sw_version", "structesp32__telemetry__t.html#af0cf4ae9955777058d07912ca1cfbad9", null ]
];