var dir_5c982d53a68cdbcd421152b4020263a9 =
[
    [ "appsm.c", "appsm_8c.html", "appsm_8c" ],
    [ "appsm.h", "appsm_8h.html", "appsm_8h" ],
    [ "initialization.c", "initialization_8c.html", "initialization_8c" ],
    [ "initialization.h", "initialization_8h.html", "initialization_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "spiffs.c", "spiffs_8c.html", "spiffs_8c" ],
    [ "spiffs.h", "spiffs_8h.html", "spiffs_8h" ],
    [ "tasksFC.c", "tasksFC_8c.html", "tasksFC_8c" ],
    [ "tasksFC.h", "tasksFC_8h.html", "tasksFC_8h" ],
    [ "tasksSC.c", "tasksSC_8c.html", "tasksSC_8c" ],
    [ "tasksSC.h", "tasksSC_8h.html", "tasksSC_8h" ]
];