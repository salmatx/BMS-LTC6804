var bms__adapter_8h =
[
    [ "bms_adapter_t", "structbms__adapter__t.html", "structbms__adapter__t" ],
    [ "bms_demo_adapter_select", "bms__adapter_8h.html#aa7725e54f855d7871050bcbe26506194", null ],
    [ "bms_get_adapter", "bms__adapter_8h.html#a9401f5daeb79453381f692767b26e71b", null ],
    [ "bms_ltc6804_adapter_select", "bms__adapter_8h.html#afe0b48b9eb2468d62f175251999f3e82", null ]
];