var stats__history_8h =
[
    [ "BMS_STATS_JSON_MAXLEN", "stats__history_8h.html#aca64faa4a44114bc1f4d618d6dfaec9a", null ],
    [ "bms_stats_hist_push", "stats__history_8h.html#a9e49f8b4d17d4e2bfcac760afe088746", null ],
    [ "bms_stats_hist_send_latest", "stats__history_8h.html#aab9a732102f42fecb9bbcf8337a3a698", null ]
];