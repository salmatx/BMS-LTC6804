var process_8h =
[
    [ "bms_stats_t", "structbms__stats__t.html", "structbms__stats__t" ],
    [ "bms_stats_buffer_t", "structbms__stats__buffer__t.html", "structbms__stats__buffer__t" ],
    [ "BMS_MAX_STATS_WINDOWS", "process_8h.html#af495a782bc075aa42c449d0e4c9ddffa", null ],
    [ "bms_compute_stats", "process_8h.html#aa4f3113b5a62b304eadc5dd2c6d09f06", null ]
];