var structbms__config__t =
[
    [ "adapter_mode", "structbms__config__t.html#a6eedc4e32408303002c6ec8044b958dd", null ],
    [ "cell_v_max", "structbms__config__t.html#ac844640ba952af418b59ff02908e03be", null ],
    [ "cell_v_min", "structbms__config__t.html#a3fedc2806929be2dfa2ec044dcfed79f", null ],
    [ "current_enable", "structbms__config__t.html#a3c5e0f6838fff8da2eb77046349a4dcb", null ],
    [ "num_cells", "structbms__config__t.html#a4d949f3a0f3dd152f391582dfbc06756", null ],
    [ "pack_v_max", "structbms__config__t.html#af078a79ec7b134a0123cb55661169ee7", null ],
    [ "pack_v_min", "structbms__config__t.html#ace4d2e0f29d67c6f5a388e0f5ae4076b", null ],
    [ "series_pack_i_max", "structbms__config__t.html#a32153ac215115f2bc446e29972e38193", null ],
    [ "series_pack_i_min", "structbms__config__t.html#afb46d5d286d74bf76ba1e675af795d2f", null ],
    [ "temperature_enable", "structbms__config__t.html#a8bb6794371eecac042d4697bfc46edee", null ]
];