var configuration_8c =
[
    [ "LOG_MODULE_TAG", "configuration_8c.html#a30f768357b7db6b4ef775e43f9580496", null ],
    [ "MAX_CONFIG_FILE_SIZE", "configuration_8c.html#a53938fdfb4ab6e2b829793e6a6bd1332", null ],
    [ "configuration_add_battery_template", "configuration_8c.html#a7f5b61150346ec5ad03633444d97c0eb", null ],
    [ "configuration_delete_battery_template", "configuration_8c.html#af5e21667f0bad9561ac935c21a0eadbf", null ],
    [ "configuration_edit_battery_template", "configuration_8c.html#a3a53f0305ff61b887fccfc2a52b580ea", null ],
    [ "configuration_get_battery_templates_json", "configuration_8c.html#aa78af68ff5195fec35dfafa15a676e41", null ],
    [ "configuration_load", "configuration_8c.html#a672d4cf31eda8fd5d9c015ffbc1522b6", null ],
    [ "configuration_save", "configuration_8c.html#a03b9d1bf27348e069ec8e07a3b8ffd0c", null ],
    [ "json_get_bool", "configuration_8c.html#ac9db6e43e7df950da42c08233676e424", null ],
    [ "json_get_float", "configuration_8c.html#ab0deab383e8f63ff66034cfaeb2435d0", null ],
    [ "json_get_int", "configuration_8c.html#ab1f5541950ef143d8ed2f1d9ef778b7f", null ],
    [ "json_get_str", "configuration_8c.html#a3203d2293c1c9106d38cb182a63cd4ae", null ],
    [ "g_cfg", "configuration_8c.html#a0f377a2b5c678e54ad1a5f3dfb713525", null ],
    [ "s_battery_templates_json", "configuration_8c.html#a2c7447b2871bfed8cf760f08eeca7043", null ]
];