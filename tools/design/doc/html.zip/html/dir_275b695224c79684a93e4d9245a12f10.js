var dir_275b695224c79684a93e4d9245a12f10 =
[
    [ "configuration.c", "configuration_8c.html", "configuration_8c" ],
    [ "configuration.h", "configuration_8h.html", "configuration_8h" ]
];