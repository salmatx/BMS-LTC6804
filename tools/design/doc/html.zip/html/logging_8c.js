var logging_8c =
[
    [ "rtc_log_buf_t", "structrtc__log__buf__t.html", "structrtc__log__buf__t" ],
    [ "RTC_LOG_MAGIC", "logging_8c.html#a07b60920faac4d564233602c003621a6", null ],
    [ "bms_log_rtc_clear", "logging_8c.html#a4f08490c8626cb5edfdbb5f4ca4c699b", null ],
    [ "bms_log_rtc_get_entries", "logging_8c.html#a5b00821139a6a9d2b302bab7bd7cc218", null ],
    [ "bms_log_rtc_store", "logging_8c.html#a1f8a046c780ffa580fc6efc8f93616fa", null ],
    [ "bms_logging_init", "logging_8c.html#a74ddcee3fc486512d5dc3229dcc9671c", null ],
    [ "bms_logging_set_global_level", "logging_8c.html#a9155e3f9bc58847dfde0349bf3c1cc15", null ],
    [ "bms_logging_set_module_level", "logging_8c.html#a985ca46846a70299325a5f3c60c39b3d", null ],
    [ "s_rtc_log", "logging_8c.html#a4bd2c0fd21e2023a40e9b7670d5585ac", null ]
];