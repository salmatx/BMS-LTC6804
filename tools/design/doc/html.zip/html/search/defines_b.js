var searchData=
[
  ['status_5fread_5finterval_0',['STATUS_READ_INTERVAL',['../tasksFC_8c.html#a121b8d8077df5b92ec8aea69a79743ef',1,'tasksFC.c']]]
];
