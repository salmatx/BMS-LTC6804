var indexSectionsWithContent =
{
  0: "abcdefghijlmnprstuvw",
  1: "abcelmrw",
  2: "abchijlmnpstw",
  3: "abcdfghijlmprstw",
  4: "abcdefghimnprstuvw",
  5: "ab",
  6: "ab",
  7: "abcdfjlmnprsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

