var searchData=
[
  ['read_5fsample_0',['read_sample',['../structbms__adapter__t.html#a87994a5fb26aa30ed0ffd34e979b2ff6',1,'bms_adapter_t']]],
  ['reset_5fmsg_1',['reset_msg',['../structesp32__telemetry__t.html#a662f245ab24c9db055919ddd0e83c6c0',1,'esp32_telemetry_t']]],
  ['reset_5freason_2',['reset_reason',['../structesp32__telemetry__t.html#a02b018ac50ffe3703d82e374d2279ed2',1,'esp32_telemetry_t']]]
];
