var searchData=
[
  ['adc_5fpin_5ft_0',['adc_pin_t',['../adc_8h.html#aa67449fc04973235c7113ef2e926af15',1,'adc.h']]],
  ['app_5fstate_5ft_1',['app_state_t',['../appsm_8c.html#a5bb27460721cc90620d197fabf50d4bb',1,'appsm.c']]]
];
