var searchData=
[
  ['device_5fid_0',['device_id',['../structesp32__telemetry__t.html#aaaff2ebeba9009c7e0a287e3c3dd8c14',1,'esp32_telemetry_t']]],
  ['diag_1',['diag',['../structltc6804__status__t.html#a36852445153ed5fc7519bd613d71a584',1,'ltc6804_status_t']]]
];
