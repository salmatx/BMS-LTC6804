var searchData=
[
  ['initialization_2ec_0',['initialization.c',['../initialization_8c.html',1,'']]],
  ['initialization_2eh_1',['initialization.h',['../initialization_8h.html',1,'']]],
  ['intercore_5fcomm_2ec_2',['intercore_comm.c',['../intercore__comm_8c.html',1,'']]],
  ['intercore_5fcomm_2eh_3',['intercore_comm.h',['../intercore__comm_8h.html',1,'']]]
];
