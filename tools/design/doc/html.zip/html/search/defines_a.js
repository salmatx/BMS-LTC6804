var searchData=
[
  ['reset_5fmsg_5fmaxlen_0',['RESET_MSG_MAXLEN',['../telemetry_8h.html#ada060123a6b035fe7f56833d91046e0f',1,'telemetry.h']]],
  ['rtc_5flog_5fmagic_1',['RTC_LOG_MAGIC',['../logging_8c.html#a07b60920faac4d564233602c003621a6',1,'logging.c']]]
];
