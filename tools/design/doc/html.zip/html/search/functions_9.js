var searchData=
[
  ['led_5fcontrol_5fget_5fstate_0',['led_control_get_state',['../led__control_8c.html#a6201c8084ae708e5ec7d7b42858bc92b',1,'led_control_get_state(void):&#160;led_control.c'],['../led__control_8h.html#a6201c8084ae708e5ec7d7b42858bc92b',1,'led_control_get_state(void):&#160;led_control.c']]],
  ['led_5fcontrol_5finit_1',['led_control_init',['../led__control_8c.html#abe2c4efa5dda90dbdad22ef05cdd0ebe',1,'led_control_init(void):&#160;led_control.c'],['../led__control_8h.html#abe2c4efa5dda90dbdad22ef05cdd0ebe',1,'led_control_init(void):&#160;led_control.c']]],
  ['led_5fcontrol_5fturn_5foff_2',['led_control_turn_off',['../led__control_8c.html#a7604643f9cc6994c47bf85ef7b0f0af2',1,'led_control_turn_off(void):&#160;led_control.c'],['../led__control_8h.html#a7604643f9cc6994c47bf85ef7b0f0af2',1,'led_control_turn_off(void):&#160;led_control.c']]],
  ['led_5fcontrol_5fturn_5fon_3',['led_control_turn_on',['../led__control_8c.html#a5d1730fc2a14e4d545fe3812be223150',1,'led_control_turn_on(void):&#160;led_control.c'],['../led__control_8h.html#a5d1730fc2a14e4d545fe3812be223150',1,'led_control_turn_on(void):&#160;led_control.c']]],
  ['ltc6804_5fadapter_5finit_4',['ltc6804_adapter_init',['../bms__adapter_8c.html#a55c39f3b2022c6ddf7503f2522cbba90',1,'bms_adapter.c']]],
  ['ltc6804_5fadapter_5fread_5fsample_5',['ltc6804_adapter_read_sample',['../bms__adapter_8c.html#af95c4a1f6a7f0226700884cc087d3fbb',1,'bms_adapter.c']]],
  ['ltc6804_5fadcv_6',['ltc6804_adcv',['../ltc6804_8c.html#a9624b86512c9ceddf4a0c1f4d8a3cd28',1,'ltc6804.c']]],
  ['ltc6804_5fadstat_7',['ltc6804_adstat',['../ltc6804_8c.html#ab2e966be5728a92e578ee959b671b2db',1,'ltc6804.c']]],
  ['ltc6804_5finit_8',['ltc6804_init',['../ltc6804_8c.html#abfff7638108ec88dab9c58cbab95e441',1,'ltc6804_init(float cell_v_min, float cell_v_max):&#160;ltc6804.c'],['../ltc6804_8h.html#abfff7638108ec88dab9c58cbab95e441',1,'ltc6804_init(float cell_v_min, float cell_v_max):&#160;ltc6804.c']]],
  ['ltc6804_5frdcfg_9',['ltc6804_rdcfg',['../ltc6804_8c.html#a9391f3182b959dc2f759bbedc71db868',1,'ltc6804.c']]],
  ['ltc6804_5frdcv_10',['ltc6804_rdcv',['../ltc6804_8c.html#afdcd2f383474ac8827639a325123c4ed',1,'ltc6804.c']]],
  ['ltc6804_5frdcv_5freg_11',['ltc6804_rdcv_reg',['../ltc6804_8c.html#a9f90f3d8cc78976f47eb9f428be135da',1,'ltc6804.c']]],
  ['ltc6804_5frdstat_5freg_12',['ltc6804_rdstat_reg',['../ltc6804_8c.html#a1694f45e96b933aa1de3c25aee961a3e',1,'ltc6804.c']]],
  ['ltc6804_5fread_5fcell_5fvoltages_13',['ltc6804_read_cell_voltages',['../ltc6804_8c.html#a0c616f6ce0b7662205e9cae6bd6cf6ba',1,'ltc6804_read_cell_voltages(float *voltages, uint8_t num_cells):&#160;ltc6804.c'],['../ltc6804_8h.html#a0c616f6ce0b7662205e9cae6bd6cf6ba',1,'ltc6804_read_cell_voltages(float *voltages, uint8_t num_cells):&#160;ltc6804.c']]],
  ['ltc6804_5fread_5fstatus_14',['ltc6804_read_status',['../ltc6804_8c.html#a86056c810d9218aecc59654444071668',1,'ltc6804_read_status(uint8_t stata[6], uint8_t statb[6]):&#160;ltc6804.c'],['../ltc6804_8h.html#a86056c810d9218aecc59654444071668',1,'ltc6804_read_status(uint8_t stata[6], uint8_t statb[6]):&#160;ltc6804.c']]],
  ['ltc6804_5fwrcfg_15',['ltc6804_wrcfg',['../ltc6804_8c.html#a41253f7d4953036ff5d56f281bd9fd68',1,'ltc6804.c']]]
];
