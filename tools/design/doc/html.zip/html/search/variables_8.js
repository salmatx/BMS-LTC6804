var searchData=
[
  ['init_0',['init',['../structbms__adapter__t.html#afb4b726e39ffaac47ecc06921231761e',1,'bms_adapter_t']]],
  ['itmp_1',['itmp',['../structltc6804__status__t.html#afd6889f0a2187a2e08a5098e4ed384e1',1,'ltc6804_status_t']]]
];
