var searchData=
[
  ['configuration_2ec_0',['configuration.c',['../configuration_8c.html',1,'']]],
  ['configuration_2eh_1',['configuration.h',['../configuration_8h.html',1,'']]]
];
