var searchData=
[
  ['rtc_5flog_5fbuf_5ft_0',['rtc_log_buf_t',['../structrtc__log__buf__t.html',1,'']]]
];
