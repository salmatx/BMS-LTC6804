var searchData=
[
  ['adapter_5fmode_0',['adapter_mode',['../structbms__config__t.html#a6eedc4e32408303002c6ec8044b958dd',1,'bms_config_t']]]
];
