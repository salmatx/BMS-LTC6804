var searchData=
[
  ['battery_0',['battery',['../structconfiguration__t.html#a50d4b6ad377eea8df311b053633a7d57',1,'configuration_t']]],
  ['buf_1',['buf',['../appsm_8c.html#ae36cb94297089dc0a916abd0705d2519',1,'appsm.c']]]
];
