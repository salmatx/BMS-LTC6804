var searchData=
[
  ['va_0',['va',['../structltc6804__status__t.html#ad0a070de153aea1f831402cbeff60258',1,'ltc6804_status_t']]],
  ['valid_1',['valid',['../structltc6804__status__t.html#a512b4fe356729e349a59677e9e419028',1,'ltc6804_status_t']]],
  ['vd_2',['vd',['../structltc6804__status__t.html#a29d1d7ab8155924ca8d68228c066a7df',1,'ltc6804_status_t']]]
];
