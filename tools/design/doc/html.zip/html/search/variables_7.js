var searchData=
[
  ['head_0',['head',['../structbms__sample__buffer__t.html#aac981cd1a096b31c4e7d5ac227481e5d',1,'bms_sample_buffer_t::head'],['../structrtc__log__buf__t.html#a5102db9d72674f836fea450485618a02',1,'rtc_log_buf_t::head']]]
];
