var searchData=
[
  ['magic_0',['magic',['../structrtc__log__buf__t.html#a82be6d7bf594bbf02e6103ba58f19ee5',1,'rtc_log_buf_t']]],
  ['min_5ffree_5fheap_1',['min_free_heap',['../structesp32__telemetry__t.html#ac582b1bde9274eab3e6cdfc11f403620',1,'esp32_telemetry_t']]],
  ['mqtt_2',['mqtt',['../structconfiguration__t.html#ab1fb6be622b20687374d9acc55174726',1,'configuration_t']]]
];
