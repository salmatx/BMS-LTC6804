var configuration_8h =
[
    [ "configuration_t", "structconfiguration__t.html", "structconfiguration__t" ],
    [ "configuration_add_battery_template", "configuration_8h.html#a7f5b61150346ec5ad03633444d97c0eb", null ],
    [ "configuration_delete_battery_template", "configuration_8h.html#af5e21667f0bad9561ac935c21a0eadbf", null ],
    [ "configuration_edit_battery_template", "configuration_8h.html#a3a53f0305ff61b887fccfc2a52b580ea", null ],
    [ "configuration_get_battery_templates_json", "configuration_8h.html#aa78af68ff5195fec35dfafa15a676e41", null ],
    [ "configuration_load", "configuration_8h.html#a672d4cf31eda8fd5d9c015ffbc1522b6", null ],
    [ "configuration_save", "configuration_8h.html#a03b9d1bf27348e069ec8e07a3b8ffd0c", null ],
    [ "g_cfg", "configuration_8h.html#a0f377a2b5c678e54ad1a5f3dfb713525", null ]
];