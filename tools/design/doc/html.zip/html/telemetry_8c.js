var telemetry_8c =
[
    [ "LOG_MODULE_TAG", "telemetry_8c.html#a30f768357b7db6b4ef775e43f9580496", null ],
    [ "get_cpu_load", "telemetry_8c.html#a256cce8fb7ef103533e86f91496dcf91", null ],
    [ "telemetry_get_device_id", "telemetry_8c.html#a5193989ab71c32c2930525e0bdcbdc14", null ],
    [ "telemetry_get_esp32_telemetry", "telemetry_8c.html#abf366230cac17b15f679fe91eebca30f", null ],
    [ "telemetry_get_ltc6804_status", "telemetry_8c.html#aa743fe65f3d4b70b0818396fcad9db51", null ],
    [ "telemetry_get_sw_version", "telemetry_8c.html#aae0a8d27ded750ee9371deff871a0460", null ],
    [ "telemetry_init", "telemetry_8c.html#a25920507197c55bea61797d223284188", null ],
    [ "telemetry_update_ltc6804_status", "telemetry_8c.html#ab6add63d30bda3b7f870cea69530a8cc", null ],
    [ "s_device_id", "telemetry_8c.html#aac84ba987871edc1f71f5127e211bee3", null ],
    [ "s_last_idle_runtime", "telemetry_8c.html#a7a116490d1ff2545270bf23f4752ba2a", null ],
    [ "s_last_total_runtime", "telemetry_8c.html#a0c13f87e2d0adbb3cbc04df01c5234f9", null ],
    [ "s_ltc_status", "telemetry_8c.html#ac5d817acfc185a91ef50dada7cdca1c8", null ],
    [ "s_ltc_status_lock", "telemetry_8c.html#adb81b7253226122daeeb3e7a71b8ee3e", null ],
    [ "s_reset_msg", "telemetry_8c.html#ae2dd0fa6695349e4f21f127b55511cd3", null ],
    [ "s_sw_version", "telemetry_8c.html#a42a846046a4d7b7c3b46e890b62effa5", null ]
];