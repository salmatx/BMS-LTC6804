var telemetry_8h =
[
    [ "esp32_telemetry_t", "structesp32__telemetry__t.html", "structesp32__telemetry__t" ],
    [ "ltc6804_status_t", "structltc6804__status__t.html", "structltc6804__status__t" ],
    [ "RESET_MSG_MAXLEN", "telemetry_8h.html#ada060123a6b035fe7f56833d91046e0f", null ],
    [ "telemetry_get_device_id", "telemetry_8h.html#a5193989ab71c32c2930525e0bdcbdc14", null ],
    [ "telemetry_get_esp32_telemetry", "telemetry_8h.html#abf366230cac17b15f679fe91eebca30f", null ],
    [ "telemetry_get_ltc6804_status", "telemetry_8h.html#aa743fe65f3d4b70b0818396fcad9db51", null ],
    [ "telemetry_get_sw_version", "telemetry_8h.html#aae0a8d27ded750ee9371deff871a0460", null ],
    [ "telemetry_init", "telemetry_8h.html#a25920507197c55bea61797d223284188", null ],
    [ "telemetry_update_ltc6804_status", "telemetry_8h.html#ab6add63d30bda3b7f870cea69530a8cc", null ]
];