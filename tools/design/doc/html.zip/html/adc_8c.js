var adc_8c =
[
    [ "ADC_CHANNEL_INVALID", "adc_8c.html#a1bdc368f6623067d9d44547fbb4c9cb5", null ],
    [ "ADC_NUM_PINS", "adc_8c.html#aced07d37660cf48cecbf808f7c3e0643", null ],
    [ "LOG_MODULE_TAG", "adc_8c.html#a30f768357b7db6b4ef775e43f9580496", null ],
    [ "adc_init", "adc_8c.html#a3cfa671db431099a0d91bd8bcfe935f8", null ],
    [ "adc_read", "adc_8c.html#a7eb91885a956bff9a16e36678790aa9b", null ],
    [ "pin_to_channel", "adc_8c.html#a8fe838e8be2409bca095b4db377386aa", null ],
    [ "s_adc_handle", "adc_8c.html#a869b41cc32e7c0b6f4d05e92a589568c", null ],
    [ "s_adc_pins", "adc_8c.html#aec2457978fd06ef4b067a4e3708787a7", null ]
];