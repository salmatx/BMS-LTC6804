var structltc6804__status__t =
[
    [ "cell_flags", "structltc6804__status__t.html#afc6b19fd7574dbe1ded43bc363410cbe", null ],
    [ "diag", "structltc6804__status__t.html#a36852445153ed5fc7519bd613d71a584", null ],
    [ "itmp", "structltc6804__status__t.html#afd6889f0a2187a2e08a5098e4ed384e1", null ],
    [ "soc", "structltc6804__status__t.html#a54f04ea967757d56a9d695db22097fea", null ],
    [ "va", "structltc6804__status__t.html#ad0a070de153aea1f831402cbeff60258", null ],
    [ "valid", "structltc6804__status__t.html#a512b4fe356729e349a59677e9e419028", null ],
    [ "vd", "structltc6804__status__t.html#a29d1d7ab8155924ca8d68228c066a7df", null ]
];