var structbms__stats__buffer__t =
[
    [ "stats_array", "structbms__stats__buffer__t.html#a384c7cda7594a0f76306a2ac723c8be7", null ],
    [ "stats_count", "structbms__stats__buffer__t.html#a659818b5d594c59092c0793bde43e035", null ]
];