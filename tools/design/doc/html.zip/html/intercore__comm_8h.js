var intercore__comm_8h =
[
    [ "BMS_QUEUE_LEN", "intercore__comm_8h.html#a0175a614034e4445f128d2f3cd3ba3fa", null ],
    [ "BMS_QUEUE_RATE_HZ", "intercore__comm_8h.html#abfbe0eda8340dc64679c991f237cbd87", null ],
    [ "BMS_QUEUE_SECONDS", "intercore__comm_8h.html#a547bd35ae22f1c5cf2a64dc47e54d4d0", null ],
    [ "bms_queue_free_slots", "intercore__comm_8h.html#a0070122564641123c9d4a5056a04ac06", null ],
    [ "bms_queue_init", "intercore__comm_8h.html#a73ddd3ef46e39e5a2a8ce8929a2963dd", null ],
    [ "bms_queue_items_waiting", "intercore__comm_8h.html#a78dcec35cce2fe3d8c81073fa568a251", null ],
    [ "bms_queue_pop", "intercore__comm_8h.html#aec952f7fa6cb1f914e87610254a72615", null ],
    [ "bms_queue_push", "intercore__comm_8h.html#ab4b62996715144005780d057d2f56b6c", null ],
    [ "g_bms_queue", "intercore__comm_8h.html#a20e76be01f4d75034cdd1b028ac4d4cc", null ],
    [ "g_bms_queue_spinlock", "intercore__comm_8h.html#ae1e8363cfc623994eae95b2e379fe787", null ]
];