var annotated_dup =
[
    [ "appsm_t", "structappsm__t.html", "structappsm__t" ],
    [ "bms_adapter_t", "structbms__adapter__t.html", "structbms__adapter__t" ],
    [ "bms_config_t", "structbms__config__t.html", "structbms__config__t" ],
    [ "bms_sample_buffer_t", "structbms__sample__buffer__t.html", "structbms__sample__buffer__t" ],
    [ "bms_sample_t", "structbms__sample__t.html", "structbms__sample__t" ],
    [ "bms_stats_buffer_t", "structbms__stats__buffer__t.html", "structbms__stats__buffer__t" ],
    [ "bms_stats_t", "structbms__stats__t.html", "structbms__stats__t" ],
    [ "configuration_t", "structconfiguration__t.html", "structconfiguration__t" ],
    [ "esp32_telemetry_t", "structesp32__telemetry__t.html", "structesp32__telemetry__t" ],
    [ "ltc6804_status_t", "structltc6804__status__t.html", "structltc6804__status__t" ],
    [ "mqtt_cfg_t", "structmqtt__cfg__t.html", "structmqtt__cfg__t" ],
    [ "rtc_log_buf_t", "structrtc__log__buf__t.html", "structrtc__log__buf__t" ],
    [ "wifi_cfg_t", "structwifi__cfg__t.html", "structwifi__cfg__t" ]
];